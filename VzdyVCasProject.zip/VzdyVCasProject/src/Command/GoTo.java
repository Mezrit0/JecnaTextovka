package Command;

import World.Location;
import World.WorldMap;

import java.util.Scanner;

public class GoTo implements Command {
    private Scanner scanner = new Scanner(System.in);
    private Location currentLocation = new Location();
    private WorldMap world = new WorldMap();

    /* 0 - Sever,
     * 1 - Východ,
     * 2 - Jih,
     * 3 - Západ
     */
    @Override
    public String execute() {
        currentLocation = world.getCurrentPosition();
        System.out.println("where u wanna go");
        String direction = scanner.next();
        System.out.println(currentLocation);
        switch (direction) {
            case "south":

            case "east":

            case "west":

            case "north":

            default:
        }

        return null;
    }

    @Override
    public boolean exit() {
        return false;
    }
}
