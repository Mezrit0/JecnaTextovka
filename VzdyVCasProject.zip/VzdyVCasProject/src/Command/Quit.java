package Command;

public class Quit implements Command {
    @Override
    public String execute() {
        return "the end";
    }

    @Override
    public boolean exit() {
        return true;
    }
}
