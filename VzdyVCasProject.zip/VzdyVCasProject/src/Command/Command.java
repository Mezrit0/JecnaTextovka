package Command;

public interface Command {

    String execute();
    boolean exit();
}
